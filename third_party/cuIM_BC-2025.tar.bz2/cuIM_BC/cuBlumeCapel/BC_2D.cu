/******************************************************************************/
//
//  GPU-based Swendsen-Wang multi-cluster algorithm for the simulation 
//  of classical spin systems
//
//    1. 2D Ising model
//    2. 2D q-state Potts model
//    3. 2D q-state clock model
//
//  Copyright (C) 2015  Yukihiro Komura, Yutaka Okabe
//  RIKEN, Advanced Institute for Computational Science
//  Department of Physics, Tokyo Metropolitan University
//
//  This program is subject to the Standard CPC licence, 
//        (http://cpc.cs.qub.ac.uk/licence/licence.html)
//
//  Prerequisite: the NVIDIA CUDA Toolkit 5.0 or newer
//
//  Related publication:
//    Y. Komura and Y. Okabe, Comput. Phys. Commun. 183, 1155-1161 (2012).
//    doi: 10.1016/j.cpc.2012.01.017
//    Y. Komura,              Comput. Phys. Commun. 194, 54-58 (2015).
//    doi:10.1016/j.cpc.2015.04.015
//
//  We use the CUDA implementation for the cluster-labeling based on 
//  the work by Hawick et al., that by Kalentev et al., and that by Komura.
//    K.A. Hawick, A. Leist, and D. P. Playne, 
//      Parallel Computing 36, 655-678 (2010).
//    O. Kalentev, A. Rai, S. Kemnitzb, and R. Schneider,
//      J. Parallel Distrib. Comput. 71, 615-620 (2011).
//    Y. Komura,             
//      Comput. Phys. Commun. 194, 54-58 (2015).
//
//  We use the NVIDIA CUDA Random Number Generation library (cuRAND) 
//
/******************************************************************************/
//
//    2. 2D q-state Potts model
//
//    model: q-state Potts model on the square lattice
//           with periodic boundary conditions
//              (2-state Potts model is equivalent to Ising model)
//    system size: nx*nx  (nx should be a multiple of 32;
//                 maximum size of nx depends on memory size)
//    number of states: q
//    choice of cluster-labeling algorithm:
//         Hawick et al.   - algorithm = 0
//         Kalentev et al. - algorithm = 1
//         Komura          - algorithm = 2
//    number of Monte Carlo steps per spin for discard:     mcs1
//    number of Monte Carlo steps per spin for measurement: mcs2
//
//    outputs:
//        2nd moment of magnetization
//        4th moment of magnetization
//        energy per spin
//        specific heat per spin
//        computational time for spin-flip  (milliseconds per a single MCS)
//        computational time for spin-flip + measurement
//                                          (milliseconds per a single MCS)
//
/******************************************************************************/
#if 0
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <assert.h>
#endif
#include <string.h>
#include <curand.h>
#if 0
__global__ void device_function_init_YK    (double, int*, int*, double*, unsigned int*);
#endif
__global__ void device_function_analysis_YK(unsigned int*);
__global__ void device_ReduceLabels        (unsigned int*, int*);
__device__ unsigned int root_find          (unsigned int*, unsigned long long int);
__global__ void device_function_spin_select(unsigned char*, double *);
#if 0
__global__ void device_function_spin_select(unsigned char*, unsigned int*);
#endif
#if 0
__global__ void device_function_spin_flip_YK(ulonglong2 *, ulonglong2 *, unsigned char *, unsigned int*  );
#endif
#undef VICTORSW
#define DEVICONST __device__ __constant__
unsigned int h_nx;  // linear system size
DEVICONST unsigned int nx;

unsigned long long int h_nla;
unsigned g_mem_N_char;
DEVICONST unsigned long long int nla;
cudaEvent_t start_timer, stop_timer;
curandGenerator_t gen;
static int  h_SPIN_X_WORD;

#if 1
unsigned char* d_spin;
#endif
#if defined(VICTORSW)
unsigned char *h_spin=NULL;
#endif
unsigned char* d_spin_new;
int* d_bond;
unsigned int* d_label;
double* d_random_data;
unsigned int* d_random_uint_data;
double beta;
double h_boltz;
DEVICONST double boltz;

unsigned int gridSW;
unsigned int PackedGridSW;
unsigned int threadsSW;

#if defined(VICTORSW)
void InitSW_Victor(double);
void SWVictor(unsigned char *);
#endif

#define MY_CUDA_CHECK( call) {                                    \
    cudaError err = call;                                                    \
    if( cudaSuccess != err) {                                                \
        fprintf(stderr, "Cuda error in file '%s' in line %i : %s.\n",        \
                __FILE__, __LINE__, cudaGetErrorString( err) );              \
        exit(EXIT_FAILURE);                                                  \
    } }

#define MY_CHECK_ERROR(errorMessage) {                                    \
    cudaError_t err = cudaGetLastError();                                    \
    if( cudaSuccess != err) {                                                \
        fprintf(stderr, "Cuda error: %s in file '%s' in line %i : %s.\n",    \
                errorMessage, __FILE__, __LINE__, cudaGetErrorString( err) );\
        exit(EXIT_FAILURE);                                                  \
    }                                                                        \
    }
#define SPLITTED_SW
#if defined(SPLITTED_SW)
template<int BITXSP>
__global__ void spin_flip_YK_custom_0(const long long n,
	   		   unsigned char *d_spin,
                           /* ulonglong2 *pck, */
                           unsigned char* d_spin_new, unsigned int* d_label) {

        static_assert(!(BIT_X_SPIN % 2));
        const unsigned long long tid = (unsigned long long)blockIdx.x*blockDim.x + threadIdx.x;
#if 0
        unsigned char spin;
        using UINT_T = decltype(pck[0].x);
	unsigned myulong2=tid/(2*((8*sizeof(UINT_T))/(BITXSP/2)));
	unsigned myposinu2=tid%(2*((8*sizeof(UINT_T))/(BITXSP/2)));
#endif	
        if (tid < n) {
#if 0	
	   	ulonglong2 p=pck[myulong2];
		if(myposinu2<((8*sizeof(UINT_T))/(BITXSP/2))) {
		   spin=((p.x)>>(myposinu2*(BITXSP/2)))&((1<<(BITXSP/2))-1);					      
		} else {
		   spin=((p.y)>>((myposinu2-((8*sizeof(UINT_T))/(BITXSP/2)))*(BITXSP/2)))&((1<<(BITXSP/2))-1);
		}

		if(spin!=0x1 && d_spin_new[( d_label[tid] )]==0x1) {
                   /* printf("changing spin %llu from value %d to %d\n",tid,ospin,spin); */
		   if(myposinu2<((8*sizeof(UINT_T))/(BITXSP/2))) {
		      atomicXor(&(pck[myulong2].x),2ULL<<(myposinu2*(BITXSP/2)));
		   } else {
		      atomicXor(&(pck[myulong2].y),2ULL<<((myposinu2-((8*sizeof(UINT_T))/(BITXSP/2)))*(BITXSP/2)));
		   }
		}
#endif
		if(d_spin[tid]!=0x1 && d_spin_new[ ( d_label[tid] ) ] == 0x1) {
		   d_spin[tid]^=0x2;
		}
	} else {
	  printf("Spin flip custom 0 Thread %llu out of %llu\n",tid,n);
	}
}

template<int BITXSP>
__global__ void spin_flip_YK_custom_1(size_t lld, const long long n,
                /*         const ulonglong2 *pck,   */
			   	 unsigned char *d_spin, 
                                 ulonglong2 *blk,
                                 ulonglong2 *wht) {
        const unsigned long long tid = (unsigned long long)blockIdx.x*blockDim.x + threadIdx.x;
        using UINT_T = decltype(blk[0].x);
	unsigned long long tspin;
	if (tid < n) {
		ulonglong2 p;
		p.x=0;
		p.y=0;
		
		unsigned long long offset=tid*2*((8*sizeof(UINT_T))/(BITXSP/2));
		for(int index=0; index<((8*sizeof(UINT_T))/(BITXSP/2)); index++) {
			tspin=(d_spin[offset+index]&((1<<(BITXSP/2))-1));
			p.x^=tspin<<(index*(BITXSP/2));
			
		}
		offset+=((8*sizeof(UINT_T))/(BITXSP/2));
		for(int index=0; index<((8*sizeof(UINT_T))/(BITXSP/2)); index++) {		
			tspin=(d_spin[offset+index]&((1<<(BITXSP/2))-1));
			p.y^=tspin<<(index*(BITXSP/2));
		}

                const int rowParity = (tid / lld) & 1;

                /*  ulonglong2 p = pck[tid];  */

                ulonglong2 b = { p.x                    & 0x3333333333333333ull,
                                 p.y                    & 0x3333333333333333ull};

                ulonglong2 w = {(p.x >> (BITXSP/2)) & 0x3333333333333333ull,
                                (p.y >> (BITXSP/2)) & 0x3333333333333333ull};

                if (rowParity) {
                        p = w;
                        w = b;
                        b = p;
                }

                blk[tid] = b;
                wht[tid] = w;
        } else {
	  printf("Spin flip custom 1 Thread %llu out of %llu\n",tid,n);
	}

        return;
}

template<int BITXSP>
__global__ void init_YK_custom_0(size_t lld, const long long n,
                             const ulonglong2 *blk,
                             const ulonglong2 *wht,
			     unsigned char *d_spin
                                   /* ulonglong2 *unp */) {

        static_assert(!(BITXSP % 2));
        using UINT_T = decltype(blk[0].x);
        const long long tid = (long long)blockIdx.x*blockDim.x + threadIdx.x;
        if (tid < n) {
                const int rowParity = (tid / lld) & 1;

                ulonglong2 b = blk[tid];
                ulonglong2 w = wht[tid];

                ulonglong2 p;

                if (rowParity) {
                        p = w;
                        w = b;
                        b = p;
                }

                p.x = b.x | (w.x << (BITXSP/2));
                p.y = b.y | (w.y << (BITXSP/2));
		unsigned long long offset=tid*2*((8*sizeof(UINT_T))/(BITXSP/2));
		for(int index=0; index<((8*sizeof(UINT_T))/(BITXSP/2)); index++) {
			d_spin[offset+index]=(p.x>>(index*(BITXSP/2)))&((1<<(BITXSP/2))-1);
			if(d_spin[offset+index]>0x2) {
			   printf("Thread %llu invalid value: %u\n",tid,d_spin[offset+index]);
			}
		}
		offset+=((8*sizeof(UINT_T))/(BITXSP/2));
		for(int index=0; index<((8*sizeof(UINT_T))/(BITXSP/2)); index++) {		
			d_spin[offset+index]=(p.y>>(index*(BITXSP/2)))&((1<<(BITXSP/2))-1);
			if(d_spin[offset+index]>0x2) {
			   printf("Thread %llu invalid value: %u\n",tid,d_spin[offset+index]);
			}
		}
		/* unp[tid] = p; */
		
        }else {
	  printf("init custom 0 Thread %llu out of %llu\n",tid,n);
	}
        return;
}

template<int BITXSP>
__global__ void init_YK_custom_1(const long long n, unsigned char *d_spin /* ulonglong2 *unp */, int* d_bond, double* d_random_data, unsigned int* d_label) {

        static_assert(!(BITXSP % 2));
	unsigned char spin;

	const unsigned long long tid = (unsigned long long)blockIdx.x*blockDim.x + threadIdx.x;
	unsigned long long la, index_min=tid;
	int bond=0;
    	spin = d_spin[tid];	
#if 0
	using UINT_T = decltype(unp[0].x);
	unsigned myulong2= tid/(2*((8*sizeof(UINT_T))/(BITXSP/2)));
	unsigned myposinu2=tid%(2*((8*sizeof(UINT_T))/(BITXSP/2)));
#endif
	if (tid < n) {
#if 0
	   	ulonglong2 p=unp[myulong2];
		if(myposinu2<((8*sizeof(UINT_T))/(BITXSP/2))) {
		   spin=((p.x)>>(myposinu2*(BITXSP/2)))&((1<<(BITXSP/2))-1);					      
		} else {
		   spin=((p.y)>>((myposinu2-((8*sizeof(UINT_T))/(BITXSP/2)))*(BITXSP/2)))&((1<<(BITXSP/2))-1);
		}
		la = (tid-1LL+nx)%nx+((long long int)(tid/nx))*nx;
		myulong2=la/(2*((8*sizeof(UINT_T))/(BITXSP/2)));
	        myposinu2=la%(2*((8*sizeof(UINT_T))/(BITXSP/2)));
		p=unp[myulong2];
		if(myposinu2<((8*sizeof(UINT_T))/(BITXSP/2))) {
		   vspin=((p.x)>>(myposinu2*(BITXSP/2)))&((1<<(BITXSP/2))-1);					      
		} else {
		   vspin=((p.y)>>((myposinu2-((8*sizeof(UINT_T))/(BITXSP/2)))*(BITXSP/2)))&((1<<(BITXSP/2))-1);
		}
		if( spin == vspin ){
       		    if( boltz < d_random_data[tid] ) {
         	    	bond |=  0x01;
         	    	index_min = min(index_min, la);
       		    }
     		}
                la = (tid-nx+nla)%nla;
		myulong2=la/(2*((8*sizeof(UINT_T))/(BITXSP/2)));
	        myposinu2=la%(2*((8*sizeof(UINT_T))/(BITXSP/2)));
		p=unp[myulong2];
		if(myposinu2<((8*sizeof(UINT_T))/(BITXSP/2))) {
		   vspin=((p.x)>>(myposinu2*(BITXSP/2)))&((1<<(BITXSP/2))-1);
		} else {
		   vspin=((p.y)>>((myposinu2-((8*sizeof(UINT_T))/(BITXSP/2)))*(BITXSP/2)))&((1<<(BITXSP/2))-1);
		}
 		if( spin == vspin ){
		    if( boltz < d_random_data[tid+nla] ) {
         	    	bond |=  (0x01<<1);
         	    	index_min = min(index_min, la);
		    }
		}
#endif
/*------------ Bond connections with left and top sites ---------------*/

    	       for(int i=0; i<2; i++){
    	        if(i==0)la = (tid-1LL+nx)%nx+((unsigned long long)(tid/nx))*nx;
  		if(i==1)la = (tid-nx+nla)%nla;
     		if( spin == d_spin[la] ){
       		    if( boltz < d_random_data[tid+i*nla] ) {
         	    	bond |=  0x01<<i;
         		index_min = min(index_min, la);
       		    }
     		}
    	       }
                // Transfer "label" and "bond" to global memory
               d_bond[tid]  = bond;
    	       d_label[tid] = index_min;
	} else {
	  printf("init custom 1 Thread %llu out of %llu\n",tid,n);
	}
	
}
#else

template<int BDIM_X,
         int BDIM_Y,
         int LOOP_X,
         int LOOP_Y,
         int BITXSP,
         int COLOR,
         typename UINT2_T>
__global__ void init_YK_custom(const int devid,
                             const long long begY,
                             const long long dimY,
                             const long long dimX, // ld
                             const UINT2_T *__restrict__ src,
                                   UINT2_T *__restrict__ dst,
			     int* d_bond, double* d_random_data, unsigned int* d_label) {

        static_assert(0 == (BDIM_X & (BDIM_X-1)));
        static_assert(0 == (BDIM_Y & (BDIM_Y-1)));
        static_assert(0 == (BITXSP & (BITXSP-1)));

        using UINT_T = decltype(src[0].x);

        constexpr int SPIN_X_WORD = 8*sizeof(UINT_T)/BITXSP;

        unsigned long long int index = (COLOR==C_WHITE)+
	                      (2*((((devid*gridDim.y + blockIdx.y)*gridDim.x + blockIdx.x)*BDIM_X*BDIM_Y +
                               threadIdx.y*BDIM_X + threadIdx.x)*(LOOP_Y*LOOP_X*2*SPIN_X_WORD)));

        const int tidx = threadIdx.x;
        const int tidy = threadIdx.y;

        __shared__ UINT2_T shTile[BDIM_Y*LOOP_Y+2][BDIM_X*LOOP_X+2];

        loadTile<BDIM_X, BDIM_Y, BDIM_X*LOOP_X, BDIM_Y*LOOP_Y>(begY, dimY, dimX, src, shTile);
        __syncthreads();

        const int __i = blockIdx.y*BDIM_Y*LOOP_Y + tidy;
        const int __j = blockIdx.x*BDIM_X*LOOP_X + tidx;

        UINT2_T __me[LOOP_Y][LOOP_X];

        #pragma unroll
        for(int i = 0; i < LOOP_Y; i++) {
                #pragma unroll
                for(int j = 0; j < LOOP_X; j++) {
                        __me[i][j] = dst[(begY+__i+i*BDIM_Y)*dimX + __j+j*BDIM_X];
                }
        }

        UINT2_T __dw[LOOP_Y][LOOP_X];
        UINT2_T __lf[LOOP_Y][LOOP_X];

        // BDIM_Y is power of two so row parity won't change across loops
        const int readBack = (COLOR == C_BLACK) ? !(__i%2) : (__i%2);

	if (readBack) {
		
		UINT2_T __sd[LOOP_Y][LOOP_X];

		#pragma unroll
		for(int i = 0; i < LOOP_Y; i++) {
			#pragma unroll
			for(int j = 0; j < LOOP_X; j++) {
				__sd[i][j] = shTile[i*BDIM_Y + 1+tidy][j*BDIM_X + tidx];
				__dw[i][j] = shTile[i*BDIM_Y + 2+tidy][j*BDIM_X + 1+tidx];
			}
		}

                #pragma unroll
                for(int i = 0; i < LOOP_Y; i++) {
                        #pragma unroll
                        for(int j = 0; j < LOOP_X; j++) {
                                __sd[i][j].x = (__lf[i][j].x << BITXSP) | (__sd[i][j].y >> (8*sizeof(__sd[i][j].y)-BITXSP));
                                __sd[i][j].y = (__lf[i][j].y << BITXSP) | (__lf[i][j].x >> (8*sizeof(__lf[i][j].x)-BITXSP));

				__lf[i][j].x = __sd[i][j].x;
				__lf[i][j].y = __sd[i][j].y;
                        }
                }
        } else {
		#pragma unroll
		for(int i = 0; i < LOOP_Y; i++) {
		#pragma unroll
			for(int j = 0; j < LOOP_X; j++) {
				__dw[i][j] = shTile[i*BDIM_Y + 2+tidy][j*BDIM_X + 1+tidx];
				__lf[i][j] = shTile[i*BDIM_Y + 1+tidy][j*BDIM_X + 1+tidx];
			}
		}
	}

	// __dw[][] down spins wrt __me[][[] (from the other color)   
	// __lf[][] left spins wrt __me[][[] (from the other color)
	unsigned char srcx, srcy, _dwx, _dwy, _lfx, _lfy;
        unsigned long long int la, index_min;
	int bond;
	#pragma unroll
        for(int i = 0; i < LOOP_Y; i++) {
                #pragma unroll
                for(int j = 0; j < LOOP_X; j++) {
                        #pragma unroll
                        for(int z = 0; z < 8*sizeof(UINT_T); z += BITXSP) {
                                srcx = (__me[i][j].x >> z) & SPIN_MASK;
			        _dwx = (__dw[i][j].x >> z) & SPIN_MASK;
        			_lfx = (__lf[i][j].x >> z) & SPIN_MASK;
				index_min=index;
				bond=0;
				if(srcx==_lfx) {
				   if(boltz<d_random_data[index] ) {
				      la=(index-1LL+nx)%nx+((long long int)(index/nx))*nx;
         			      bond |=  0x01;
         			      index_min = min(index_min, la);
				    }
				}
				if(srcx==_dwx) {
				   if(boltz<d_random_data[index+nla] ) {
				      la=(index-nx+nla)%nla;
				      bond |=  0x01<<1;
         			      index_min = min(index_min, la);
				    }
				}
				// Transfer "label" and "bond" to a global memory
				d_bond[index]  = bond;
    				d_label[index] = index_min;
				index+=2;
			}
                        for(int z = 0; z < 8*sizeof(UINT_T); z += BITXSP) {                        
                                srcy = (__me[i][j].y >> z) & SPIN_MASK;
                                _dwy = (__dw[i][j].y >> z) & SPIN_MASK;
				_lfy = (__lf[i][j].y >> z) & SPIN_MASK;
			        index_min=index;
				bond=0;
				if(srcy==_lfy) {
				   if(boltz<d_random_data[index] ) {
				      la=(index-1LL+nx)%nx+((long long int)(index/nx))*nx;				          			       bond |=  0x01 ;
         			      index_min = min(index_min, la);
				    }
				}
				if(srcy==_dwy) {
				   if(boltz<d_random_data[index+nla] ) {
				      la=(index-nx+nla)%nla;
				      bond |=  0x01<<1;
         			      index_min = min(index_min, la);
				    }
				}
				// Transfer "label" and "bond" to a global memory
				d_bond[index]  = bond;
    				d_label[index] = index_min;
				index+=2;
                        }
		}
        }
}

template<int BDIM_X,
         int BDIM_Y,
         int LOOP_X,
         int LOOP_Y,
         int BITXSP,
         int COLOR,
         typename UINT2_T>
__global__ void spin_flip_YK_custom(const int devid,
                             const long long begY,
                             const long long dimY,
                             const long long dimX, // ld
                                   UINT2_T *__restrict__ dst,
			           unsigned char* d_spin_new, unsigned int* d_label) {

        static_assert(0 == (BDIM_X & (BDIM_X-1)));
        static_assert(0 == (BDIM_Y & (BDIM_Y-1)));
        static_assert(0 == (BITXSP & (BITXSP-1)));

        using UINT_T = decltype(dst[0].x);

        constexpr int SPIN_X_WORD = 8*sizeof(UINT_T)/BITXSP;

        unsigned long long int index = (COLOR==C_WHITE)+
	                      (2*((((devid*gridDim.y + blockIdx.y)*gridDim.x + blockIdx.x)*BDIM_X*BDIM_Y +
                               threadIdx.y*BDIM_X + threadIdx.x)*(LOOP_Y*LOOP_X*2*SPIN_X_WORD)));

        const int tidx = threadIdx.x;
        const int tidy = threadIdx.y;

        const int __i = blockIdx.y*BDIM_Y*LOOP_Y + tidy;
        const int __j = blockIdx.x*BDIM_X*LOOP_X + tidx;

        UINT2_T __me[LOOP_Y][LOOP_X];

        #pragma unroll
        for(int i = 0; i < LOOP_Y; i++) {
                #pragma unroll
                for(int j = 0; j < LOOP_X; j++) {
                        __me[i][j] = dst[(begY+__i+i*BDIM_Y)*dimX + __j+j*BDIM_X];
                }
        }

	unsigned char srcx, srcy;
	#pragma unroll
        for(int i = 0; i < LOOP_Y; i++) {
                #pragma unroll
                 for(int j = 0; j < LOOP_X; j++) {
                        #pragma unroll
                        for(int z = 0; z < 8*sizeof(UINT_T); z += BITXSP) {
                                srcx = (__me[i][j].x >> z) & SPIN_MASK;
    				if(srcx!=0x1 && d_spin_new[( d_label[index] )]==0x1) {
				       __me[i][j].x^=(unsigned long long)((0x2ULL)<<z); /* invert 0 and 2 */ 
    				}
				index+=2;
			}
                        for(int z = 0; z < 8*sizeof(UINT_T); z += BITXSP) {                        
                                srcy = (__me[i][j].y >> z) & SPIN_MASK;
				if(srcy!=0x1 && d_spin_new[( d_label[index] )]==0x1) {
				       __me[i][j].y^=(unsigned long long)((0x2ULL)<<z); /* invert 0 and 2 */ 
    				}
				index+=2;
                        }
		}
        }
        #pragma unroll
        for(int i = 0; i < LOOP_Y; i++) {
                #pragma unroll
                for(int j = 0; j < LOOP_X; j++) {
                        dst[(begY+__i+i*BDIM_Y)*dimX + __j+j*BDIM_X]=__me[i][j];
                }
        }
	
}
#endif

void SWinit(unsigned int L, unsigned int threads, unsigned long long seed, double t) {

/*------------ Variables for GPU command ------------------------------*/
    h_nx=L;

    h_nla = ((unsigned long long)h_nx)*((unsigned long long)h_nx);
 
    MY_CUDA_CHECK( cudaMemcpyToSymbol(nx,&h_nx,sizeof(unsigned int),0,cudaMemcpyHostToDevice) );
    MY_CUDA_CHECK( cudaMemcpyToSymbol(nla,&h_nla,sizeof(unsigned long long int),0,cudaMemcpyHostToDevice) );
    
    threadsSW=threads;
    gridSW    = (h_nla+threadsSW-1)/((unsigned long long int)threadsSW);
    if(gridSW>=((1LL<<31)-1)) {
       fprintf(stderr,"Invalid number of blocks: max is %lld\n",(1LL<<31)-1);
       exit(1);
    }

    h_SPIN_X_WORD = (8*sizeof(unsigned long long))/BIT_X_SPIN;

    PackedGridSW    = h_nla/(2*2*h_SPIN_X_WORD)/((unsigned long long int)threadsSW);
 
    cudaEventCreate( &start_timer );
    cudaEventCreate( &stop_timer  );

/*------------ Size of array ------------------------------------------*/

    unsigned long long int mem_N                 = sizeof(int)*(h_nla);
    unsigned long long int mem_N_char            = sizeof(unsigned char)*(h_nla);
    g_mem_N_char=mem_N_char;
    unsigned long long int mem_rand              = sizeof(double)*(2*h_nla);
#if 0
    unsigned long long int mem_rand_uint         = sizeof(unsigned int)*(h_nla);
#endif
    MY_CUDA_CHECK( cudaMalloc((void**) &d_spin       , mem_N_char   ) );
    MY_CUDA_CHECK( cudaMalloc((void**) &d_spin_new   , mem_N_char   ) );

    MY_CUDA_CHECK( cudaMalloc((void**) &d_bond       , mem_N   ) );
    MY_CUDA_CHECK( cudaMalloc((void**) &d_label      , mem_N   ) );

    MY_CUDA_CHECK( cudaMalloc((void**) &d_random_data, mem_rand) );
#if 0
    MY_CUDA_CHECK( cudaMalloc((void**) &d_random_uint_data, mem_rand_uint) );
#endif
/*------------ Set of initial random numbers --------------------------*/


//
//  You can choose several random number generations: 
//  CURAND_RNG_PSEUDO_XORWOW(=CURAND_RNG_PSEUDO_DEFAULT), 
//  CURAND_RNG_PSEUDO_MRG32K3A, CURAND_RNG_PSEUDO_MTGP32,
//  CURAND_RNG_PSEUDO_PHILOX4_32_10, CURAND_RNG_PSEUDO_MT19937
//
    curandCreateGenerator(&gen, CURAND_RNG_PSEUDO_DEFAULT);
    cudaDeviceSynchronize();
    curandSetPseudoRandomGeneratorSeed(gen, (unsigned long long)seed);
    cudaDeviceSynchronize();
#if 0
/*------------ Start of GPU calculation -------------------------------*/

    printf("#\n");
    printf("#  GPU-based Swendsen-Wang multi-cluster algorithm ");
    printf("#      (Komura algorithm for cluster-labeling)\n");    
    printf("#  Related publication:\n");
    printf("#    Y. Komura and Y. Okabe, Comput. Phys. Commun. ");
    printf("183, 1155-1161 (2012).\n");
    printf("#    doi: 10.1016/j.cpc.2012.01.017\n");
    printf("#    Y. Komura, Comput. Phys. Commun. ");
    printf("194, 54-58 (2015).\n");
    printf("#    doi: 10.1016/j.cpc.2015.04.015\n");
    printf("#\n");
#endif
    beta = 1.0/t;
    h_boltz = exp(-2*beta);
    printf("h_nla=%llu, h_SPIN_X_WORD=%d, gridSW=%u, PackedGridSW=%u, boltz=%lf\n",h_nla,h_SPIN_X_WORD,gridSW,PackedGridSW,h_boltz);
    MY_CUDA_CHECK( cudaMemcpyToSymbol(boltz,&h_boltz,sizeof(double),0,cudaMemcpyHostToDevice) );
#if defined(VICTORSW)
    h_spin=(unsigned char *)malloc(mem_N_char);
    if(h_spin==NULL) {
       fprintf(stderr,"Could not get memory for h_spin (%d bytes)\n",mem_N_char);
       exit(0);
    }
    InitSW_Victor(t);
#endif    
}    

#if defined(SPLITTED_SW)
void SWstep(int Y, size_t lld, ulonglong2 *black_m, ulonglong2 *white_m) {
#else
void SWstep(int Y, size_t lld, dim3 grid, dim3 block, ulonglong2 *black_m, ulonglong2 *white_m) {
#endif


      cudaEventRecord( start_timer, 0 );
      //float flip_timer;
#if !defined(SPLITTED_SW)
      int ndev=1;
      int idev=0;
#endif      
// Random number generation
      curandGenerateUniformDouble(gen, d_random_data, 2*h_nla);
//      curandGenerate(gen, d_random_uint_data, h_nla);
#if defined(SPLITTED_SW)
      // Bond connection
      init_YK_custom_0<BIT_X_SPIN><<<PackedGridSW, threadsSW>>>(lld, h_nla/(2*2*h_SPIN_X_WORD), black_m, white_m, d_spin /* black_m  */);
#if defined(VICTORSW)
      cudaMemcpy(h_spin,d_spin,g_mem_N_char,cudaMemcpyDeviceToHost);
      for(int i=0;i<h_nla; i++) {
      /* Victor's convention 
      	 S=-1 ---> u=3
	 S= 1 ---> u=2
	 S= 0 ---> u=0
      */
	if(h_spin[i]==0) {h_spin[i]=3;} else if(h_spin[i]==1) {h_spin[i]=0;} else if(h_spin[i]!=2) {printf("Unexpected spin %d in %d\n",h_spin[i],i);}
      }
      printf("Calling SWVictor\n");
      SWVictor(h_spin);
      for(int i=0;i<h_nla; i++) {
	if(h_spin[i]==3) {h_spin[i]=0;} else if(h_spin[i]==0) {h_spin[i]=1;} else if(h_spin[i]!=2) {printf("Unexpected spin %d in %d\n",h_spin[i],i);}
      }

      cudaMemcpy(d_spin,h_spin,g_mem_N_char,cudaMemcpyHostToDevice);
#else      
      MY_CUDA_CHECK(cudaDeviceSynchronize());
      init_YK_custom_1<BIT_X_SPIN><<<gridSW, threadsSW>>>(h_nla, /* black_m */d_spin, d_bond, d_random_data, d_label);
      MY_CUDA_CHECK(cudaDeviceSynchronize());
#endif     
#else
     // Bond connection
      init_YK_custom<BLOCK_X, BLOCK_Y, BREAD_X, BREAD_Y, BIT_X_SPIN, C_BLACK>
                  <<<grid, block>>>(idev, idev*Y, ndev*Y, lld, white_m, black_m,
		  d_bond, d_random_data, d_label);        
      MY_CUDA_CHECK(cudaDeviceSynchronize());
      init_YK_custom<BLOCK_X, BLOCK_Y, BREAD_X, BREAD_Y, BIT_X_SPIN, C_WHITE>
                  <<<grid, block>>>(idev, idev*Y, ndev*Y, lld, black_m, white_m,
		  d_bond, d_random_data, d_label);        
      MY_CUDA_CHECK(cudaDeviceSynchronize());
#endif
      // Cluster formation
      device_function_analysis_YK<<<gridSW,threadsSW>>>(d_label);
      device_ReduceLabels<<<gridSW,threadsSW>>>(d_label,d_bond);
      device_function_analysis_YK<<<gridSW,threadsSW>>>(d_label);
      
      curandGenerateUniformDouble(gen, d_random_data, h_nla);      
      // Spin flip process
      device_function_spin_select<<<gridSW,threadsSW>>>(d_spin_new, d_random_data);

#if  defined(SPLITTED_SW)
#if !defined(VICTORSW)
      spin_flip_YK_custom_0<BIT_X_SPIN><<<gridSW, threadsSW>>>(h_nla, d_spin /* black_m */, d_spin_new, d_label);
      MY_CUDA_CHECK(cudaDeviceSynchronize());
#endif      
      spin_flip_YK_custom_1<BIT_X_SPIN><<<PackedGridSW, threadsSW>>>(lld,h_nla/(2*2*h_SPIN_X_WORD), /* black_m */ d_spin, black_m, white_m);
      MY_CUDA_CHECK(cudaDeviceSynchronize());
#else
      // device_function_spin_select<<<gridSW,threadsSW>>>(d_spin_new, d_random_uint_data);
      spin_flip_YK_custom<BLOCK_X, BLOCK_Y, BREAD_X, BREAD_Y, BIT_X_SPIN, C_BLACK>
                  <<<grid, block>>>(idev, idev*Y, ndev*Y, lld, black_m, d_spin_new, d_label);        
      MY_CUDA_CHECK(cudaDeviceSynchronize());
      spin_flip_YK_custom<BLOCK_X, BLOCK_Y, BREAD_X, BREAD_Y, BIT_X_SPIN, C_WHITE>
                  <<<grid, block>>>(idev, idev*Y, ndev*Y, lld, white_m, d_spin_new, d_label);        
      MY_CUDA_CHECK(cudaDeviceSynchronize());
#endif      
#if 0
      cudaEventRecord( stop_timer, 0 );
      cudaEventSynchronize( stop_timer );
      cudaEventElapsedTime( &flip_timer, start_timer, stop_timer );
#endif
}
/*------------- Cleaning of memory ------------------------------------*/

void SWclose() { 
    curandDestroyGenerator(gen);
    cudaEventDestroy( start_timer );
    cudaEventDestroy( stop_timer );
    cudaFree(d_spin_new);
    cudaFree(d_bond);
    cudaFree(d_label);
    cudaFree(d_random_data);
#if 0
    cudaFree(d_random_uint_data);
#endif
}


/*****************************************************************************
        Device functions (GPU)
*****************************************************************************/


//****************************************************************************
#if 0
__global__ void device_function_init_YK(double d_t, int* d_spin, 
              int* d_bond, double* d_random_data, unsigned int* d_label)
/*
     Bond connection
        (Komura algorithm)
*/
{
    unsigned long long int index = ((unsigned long long)blockIdx.x) * blockDim.x + threadIdx.x;
    unsigned long long int la, index_min;
    unsigned int i;
    int spin, bond;
    __shared__ double boltz;

    spin = d_spin[index];
    bond = 0;
    index_min = index;
    if(threadIdx.x==0){
      boltz = d_t;
    }
    __syncthreads();

/*------------ Bond connections with left and top sites ---------------*/

    for(i=0; i<2; i++){
     if(i==0)la = (index-1LL+nx)%nx+((long long int)(index/nx))*nx;
     if(i==1)la = (index-nx+nla)%nla;
     if( spin == d_spin[la] ){
       if( boltz < d_random_data[index+i*nla] ) {
         bond |=  0x01<<i;
         index_min = min(index_min, la);
       }
     }
    }

/*------------ Transfer to global memories ----------------------------*/

    // Transfer "label" and "bond" to a global memory
    d_bond[index]  = bond;
    d_label[index] = index_min;
}
#endif

//****************************************************************************
__global__ void device_function_analysis_YK(unsigned int* d_label)
/*
     Equivalence chain of "label": repeat the calculation up to the point 
           such that d_label[d_label[...[index]...]] = d_label[...[index]...];
        (Komura algorithm)
*/
{
    unsigned long long int index = ((unsigned long long)blockIdx.x) * blockDim.x + threadIdx.x;

    d_label[index] = root_find(d_label, index);
}


//****************************************************************************
__global__ void device_ReduceLabels(unsigned int* d_label, 
                                                    int* d_bond )
/*
     Label reduction method. 
     Please see the pseudo-code of Algorithm 1 in 
     Comput. Phys. Commun. 194, 54-58 (2015).
*/
{
    unsigned long long int index = ((unsigned long long)blockIdx.x) * blockDim.x + threadIdx.x;
    unsigned long long int la;
    unsigned int bond;
    unsigned int label_1, label_2, label_3, flag;

    bond = d_bond[index];

    __syncthreads();

/*------------ Comparison with "label" of left site -------------------*/

    flag = 0;

    label_1 = root_find(d_label, index);
    if( (bond)&0x01 == 1 ){
      la = (index-1+nx)%nx+((int)(index/nx))*nx;
      label_2 = root_find(d_label, la);
      if(label_1!=label_2) flag = 1;
    }

    if(label_1 < label_2){ 
     label_3=label_1; 
     label_1=label_2; 
     label_2=label_3; 
    }
    while( flag == 1 ){
     label_3 = atomicMin(&d_label[label_1], label_2);
     if(label_3==label_2){ flag = 0;        }
     else if(label_3>label_2){ label_1=label_3;                 }
     else if(label_3<label_2){ label_1=label_2; label_2=label_3;}
    }

/*------------ Comparison with "label" of top boudanry site -------------------*/

   if(index<nx){
    flag = 0;

    label_1 = root_find(d_label, index);
    if( (bond>>1)&0x01 == 1 ){
     la = (index-nx+nla)%nla;
     label_2 = root_find(d_label, la);
     if(label_1!=label_2)flag = 1;
    }
    
    if(label_1 < label_2){ 
     label_3=label_1; 
     label_1=label_2; 
     label_2=label_3; 
    }
    while( flag == 1 ){
     label_3 = atomicMin(&d_label[label_1], label_2);
     if(label_3==label_2){ flag = 0;        }
     else if(label_3>label_2){ label_1=label_3;                 }
     else if(label_3<label_2){ label_1=label_2; label_2=label_3;}
    }
   }
}


//****************************************************************************
__device__ unsigned int  root_find(
  unsigned int* d_label, unsigned long long int index )
/* 
     Equivalence chain of "label": repeat the calculation up to the point 
           such that d_label[d_label[...[index]...]] = d_label[...[index]...];
*/
{

    unsigned long long int ref, t_label;

    t_label = index;
    ref = d_label[t_label];

    while( ref != t_label){
      t_label = ref;
      ref = d_label[t_label];
    }

  return ref;
}


//****************************************************************************
__global__ void device_function_spin_select(unsigned char* d_spin_new,
#if 0
                unsigned int* d_random_uint_data)
#endif		
                double* d_random_data)
/*
     Set a new spin state for each "label"
*/
{
    unsigned long long int index = ((unsigned long long)blockIdx.x) * blockDim.x + threadIdx.x;
#if 0
    int spin_new;
#endif
/*  Original code for Potts' model 
    spin_new = d_random_uint_data[index]%q;
*/
#if 0
    spin_new = d_random_uint_data[index]&0x1;
    d_spin_new[index] = spin_new;        
#endif    
    d_spin_new[index] = (d_random_data[index]<0.5);    
}


//****************************************************************************
#if 0
__global__ void device_function_spin_flip_YK(ulonglong2 *black_m, ulonglong2 *white_m, unsigned char* d_spin_new, 
                unsigned int* d_label)
/*
     Set a new spin state for each site with chosen "label"
*/
{
    unsigned long long int index = ((unsigned long long)blockIdx.x) * blockDim.x + threadIdx.x;
    if(d_spin[index]!=0x1 && d_spin_new[( d_label[index] )]==0x1) {
       d_spin[index]^=0x00000002; /* invert 0 and 2 */ 
    }
}
#endif
