#ifndef __COMMON_H__
#define __COMMON_H__

#ifdef USE_MNNVL
#include <mpi.h>
#include "vmm_alloc.h"
#endif
#include "cudamacro.h" /* for time() */
#include "utils.h"

#define DIV_UP(a,b)     (((a)+((b)-1))/(b))
#define THREADS  (64)

#define WARP_SIZE (32)

#define MIN(a,b)        (((a)<(b))?(a):(b))
#define MAX(a,b)        (((a)>(b))?(a):(b))

#define MAX_GPU   (256)

#define NUMIT_DEF (1)

#define SEED_DEF  (463463564571ull)

#define ONE_GB (1<<30)

#define MAX_TEMPS (10)

#define __2POW32M1U  (-1u)
#define __2POW31M1U  ((1u<<31)-1)
#define __2POW31O3U  ((__2POW31M1U+2) / 3)

#define PRINTF1(...)  { if (!rank) { printf(__VA_ARGS__); fflush(stdout); } }
#define FPRINTF1(...) { if (!rank) { printf(__VA_ARGS__); } }

__device__ __forceinline__ unsigned int __mypopc(const unsigned int x) {
        return __popc(x);
}

__device__ __forceinline__ unsigned long long int __mypopc(const unsigned long long int x) {
        return __popcll(x);
}

__device__ __forceinline__ uint2 mymake_uint2(const unsigned int x,
                                              const unsigned int y) {
        return make_uint2(x, y);
}

__device__ __forceinline__ ulonglong2 mymake_uint2(const unsigned long long x,
                                                   const unsigned long long y) {
        return make_ulonglong2(x, y);
}

// Meant to be called with 1 thread
__global__ void setFlag_k(const long long it, long long *ptr) {
        ptr[0] = it;
        return;
}

__device__ __forceinline__ long long __ld_strong_glb(long long *ptr) {

        long long ret;
        asm volatile("ld.relaxed.sys.global.u64 %0, [%1];\n\t" : "=l"(ret) : "l"(ptr) : "memory");
        return ret;
}

__device__ __forceinline__ void __st_strong_glb(long long *ptr, long long val) {

        asm volatile("st.relaxed.sys.global.u64 [%0], %1;\n\t" :: "l"(ptr), "l"(val) : "memory");
        return;
}

__global__ void setAndWaitFlag_k(long long value,
                                 long long *__restrict__ setPtr,
                                 long long *__restrict__ chkPtr) {

        __st_strong_glb(setPtr, value);

        long long v;
        do { v = __ld_strong_glb(chkPtr); } while (v != value);

        return;
}

#endif
